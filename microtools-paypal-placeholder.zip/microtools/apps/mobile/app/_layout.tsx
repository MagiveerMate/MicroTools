import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
export default function Layout(){return <><StatusBar style="auto"/><Stack screenOptions={{headerShadowVisible:false,headerTitleStyle:{fontWeight:'700'}}}/></>}
